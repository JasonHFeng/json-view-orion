<template lang="pug">

</template>

<script lang="ts" setup>
/**
 * ${NAME}
 */
</script>

<style lang="stylus" scoped>

</style>