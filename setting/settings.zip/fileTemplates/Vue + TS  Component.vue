<template>
  <div></div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

@Component({
  name: '${NAME}'
})
export default class ${NAME} extends Vue {}
</script>