import React, { FC } from 'react'

const ${NAME}: FC = () => {
  return (
    <div>${NAME}</div>
  )
}

export default ${NAME}
