<template>
#[[$END$]]#
</template>

<script>
/**
 * ${COMPONENT_NAME}
 */
export default {
  name: '${COMPONENT_NAME}'
}
</script>

<style lang="stylus" scoped>

</style>